#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include "graph.h"

Graph input_data_from_file(char* file_name)
{
    Graph G = createGraph();
    FILE* f = fopen(file_name, "r");
    int n, m;
    int id1, id2, distance;
    int arr[MAX_ID][MAX_ID] = {0}; // Ma tran ke
    fscanf(f, "%d\t%d", &n, &m);
    for (int i = 0; i < m; ++i)
    {
        fscanf(f, "%d\t%d\t%d", &id1, &id2, &distance);
        if(!jrb_find_int(G.vertices, id1))
            addVertex(G, id1, "NONE");
        if(!jrb_find_int(G.vertices, id2))
            addVertex(G, id2, "NONE");
        addEdge(G, id1, id2, distance);
        addEdge(G, id2, id1, distance);
        arr[id1][id2] = 1;
        arr[id2][id1] = 1;
    }

    // Show matrix
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= n; ++j)
            printf("%d ", arr[i][j]);
        puts("");
    }

    fclose(f);
    return G;
}

// Danh sach ke
void func2(Graph G)
{
    JRB iter;
    int n, output[MAX_ID];
    jrb_traverse(iter, G.vertices)
    {
        n = outdegree(G, jval_i(iter->key), output);
        printf("Castle %d: ", jval_i(iter->key));
        for (int i = 0; i < n; ++i)
            printf("%d ", output[i]);
        puts("");
    }
}

void func3(Graph G)
{
    JRB iter;
    int n, output[MAX_ID];
    
    /* 3a */
    int flag;
    printf("Cac thanh tri chi co the di bo: ");
    jrb_traverse(iter, G.vertices)
    {
        n = indegree(G, jval_i(iter->key), output);
        flag = true;
        for (int i = 0; i < n; ++i)
            if (getEdgeValue(G, jval_i(iter->key), output[i]) < 50)
            {
                flag = false;
                break;
            }
        if (flag)
            printf("%d ", jval_i(iter->key));
    }
    puts("");

    /* 3b */
    int max = 0;
    // Tim max
    jrb_traverse(iter, G.vertices)
    {
        n = indegree(G, jval_i(iter->key), output);
        if (n > max)
            max = n;
    }

    printf("Cac thanh tri co nhieu duong noi nhat (%d): ", max);
    jrb_traverse(iter, G.vertices)
    {
        n = indegree(G, jval_i(iter->key), output);
        if (n == max)
            printf("%d ", jval_i(iter->key));
    }
    puts("");
}

void func4(Graph G)
{
    int s, t, length, path[MAX_ID];
    double distance;

    printf("Thanh tri xuat phat: "); scanf("%d", &s);
    printf("Thanh tri dich: "); scanf("%d", &t);
    distance = shortestPath(G, s, t, path, &length);
    if (distance == INFINITIVE_VALUE)
        printf("ROUTE NOT FOUND\n");
    else
    {
        printf("Do dai duong di: %.0lf\n", distance);
        for (int i = 0; i < length-1; ++i)
            printf("%d -> ", path[i]);
        printf("%d\n", path[length-1]);
    }
        
}

void func5(Graph G)
{
    // Neu khong co duong di bo (< 50) => coi nhu la INF
    Graph new_graph = createGraph();
    JRB iter, tree, node;
    int n, output[MAX_ID];

    jrb_traverse(iter, G.vertices)
        addVertex(new_graph, jval_i(iter->key), "NONE");
    jrb_traverse(iter, G.edges)
    {
        tree = (JRB) jval_v(iter->val); // Dinh ke
        jrb_traverse(node, tree)
            if (jval_d(node->val) >= 50)
                addEdge(new_graph, jval_i(iter->key), jval_i(node->key), jval_d(node->val));
    }

    int path[MAX_ID], length, s, t;
    double distance;

    printf("Thanh tri xuat phat: "); scanf("%d", &s);
    printf("Thanh tri dich: "); scanf("%d", &t);
    distance = shortestPath(new_graph, s, t, path, &length);
    if (distance == INFINITIVE_VALUE)
        printf("ROUTE NOT FOUND\n");
    else
    {
        printf("Do dai duong di: %.0lf\n", distance);
        for (int i = 0; i < length-1; ++i)
            printf("%d -> ", path[i]);
        printf("%d\n", path[length-1]);
    }

    dropGraph(new_graph);
}

int main(int argc, char* argv[])
{
    int select;
    Graph G;
    do
    {
        printf("Menu:\n");
        printf(">>> "); scanf("%d", &select);
        switch (select)
        {
        case 1:
            G = input_data_from_file("dothi.txt");
            break;
        case 2:
            func2(G);
            break;
        case 3:
            func3(G);
            break;
        case 4:
            func4(G);
            break;
        case 5:
            func5(G);
            break;        
        default:
            dropGraph(G);
            return 0;
        }
    } while (true);
}