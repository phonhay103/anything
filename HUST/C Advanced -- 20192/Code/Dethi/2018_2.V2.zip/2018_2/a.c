#include "graph.h"

int main()
{
    Graph G = createGraph();
    addVertex(G, 1, "A");
    addVertex(G, 2, "B");
    addVertex(G, 3, "C");

    addEdge(G, 1, 2, 300);

    return 0;
}