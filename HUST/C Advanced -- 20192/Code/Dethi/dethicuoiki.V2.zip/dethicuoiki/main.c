#include <stdio.h>
#include "graph.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// Hien chi ap dung cho toi da 10 hang 10 cot
char* get_id(int i, int j) // Ghep i va j lai thanh id (row column)
{
    char ch[3];
    ch[0] = i+48; // int -> char
    ch[1] = j+48; // int -> char
    ch[2] = '\0';
    return strdup(ch);
}

int read_file(Graph G, char* file_name)
{
    FILE* f = fopen(file_name, "r");
    if (f == NULL)
    {
        printf("Mo file khong thanh cong\n");
        return 0;
    }

    int arr[MAX_ID][MAX_ID];
    int n = 10; // Kich thuoc ma tran vuong (cho truoc)
    
    for (int i = 0; i < n; ++i)
        // fscanf(f, "%d %d %d %d %d\n", &arr[i][0], &arr[i][1], &arr[i][2], &arr[i][3], &arr[i][4]);
        fscanf(f, "%d %d %d %d %d %d %d %d %d %d\n", &arr[i][0], &arr[i][1], &arr[i][2], &arr[i][3], &arr[i][4], &arr[i][5], &arr[i][6], &arr[i][7], &arr[i][8], &arr[i][9]);
    // printf("Ma tran: \n");
    // for (int i = 0; i < n; ++i)
        // printf("%d %d %d %d %d\n", arr[i][0], arr[i][1], arr[i][2], arr[i][3], arr[i][4]); // In ra man hinh


    // Xet cac o xung quanh cua tung o mot
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            if (arr[i][j] == 0)
            {
                addVertex(G, atoi(get_id(i, j)), get_id(i, j));
                // O ben trai
                if (j > 0 && arr[i][j-1] == 0)
                    addEdge(G, atoi(get_id(i, j)), atoi(get_id(i, j-1)), 1);
                // O ben phai
                if (j < n-1 && arr[i][j+1] == 0)
                    addEdge(G, atoi(get_id(i, j)), atoi(get_id(i, j+1)), 1);
                // O ben tren
                if (i > 0 && arr[i-1][j] == 0)
                    addEdge(G, atoi(get_id(i, j)), atoi(get_id(i-1, j)), 1);
                // O ben duoi
                if (i < n-1 && arr[i+1][j] == 0)
                    addEdge(G, atoi(get_id(i, j)), atoi(get_id(i+1, j)), 1);
            }
    fclose(f);
    return 1;
}

void func2(Graph G)
{
    int num_vertexs = 0, num_edges = 0;
    JRB iter;
    int output[MAX_ID];

    jrb_traverse(iter, G.vertices)
    {
        num_edges += outdegree(G, jval_i(iter->key), output);
        num_vertexs++;
    }
    printf("Vertexs: %d\n", num_vertexs);
    printf("Edges: %d\n", num_edges/2); // Chia 2 do do thi vo huong co su trung lap
}

void func3(Graph G)
{
    int n, output[MAX_ID];
    int v;
    printf("Nhap 1 diem: "); scanf("%d", &v);

    if (!jrb_find_int(G.vertices, v))
    {
        printf("Khong co trong do thi\n");
        return;
    }

    n = outdegree(G, v, output);
    if (n > 0)
    {
        for (int i = 0; i < n; ++i)
            printf("%s ", getVertex(G, output[i]));
        puts("");
    }
}

void func4(Graph G)
{
    int n, output[MAX_ID];
    int max_edge = 0;
    JRB iter;

    jrb_traverse(iter, G.edges)
    {
        n = outdegree(G, jval_i(iter->key), output);
        if (n > max_edge)
            max_edge = n;
    }
    jrb_traverse(iter, G.edges)
    {
        n = outdegree(G, jval_i(iter->key), output);
        if (n == max_edge)
            printf("MAX: %s --- %d\n", getVertex(G, jval_i(iter->key)), max_edge);
    }
}

void func5(Graph G)
{
    JRB iter;
    int output[MAX_ID];
    jrb_traverse(iter, G.vertices)
    {
        if (outdegree(G, jval_i(iter->key), output) == 0) // if (!jrb_find_int(G.edges, jval_i(iter->key))
            printf("%s ", getVertex(G, jval_i(iter->key)));
    }    
}

void func6(Graph G)
{
    int length, path[MAX_ID];
    int start, end;
    printf("Nhap diem dau va diem cuoi: "); scanf("%d %d", &start, &end);
    double distance = shortestPath(G, start, end, path, &length);
    if (distance == INFINITIVE_VALUE)
        printf("Khong co duong di giua 2 diem\n");
    else
    {
        for (int i = 0; i < length-1; ++i)
            printf("%s -> ", getVertex(G, path[i]));
        printf("%s\n", getVertex(G, path[length-1]));
    }
}

int visited[MAX_ID] = {0};
void backtrack(Graph G, int s, int t, int* n)
{
    visited[s] = 1;
    if (s == t)
    {
        (*n)++;
        return;
    }
    else
    {
        int num, output[MAX_ID];
        num = outdegree(G, s, output);
        for (int i = 0; i < num; ++i)
            if (visited[output[i]] == 0)
            {
                backtrack(G, output[i], t, n);
                visited[output[i]] = 0; // Quay nguoc lai
            }
    }
}

void func7(Graph G)
{
    int s, t;
    int n = 0;
    for (int i = 0; i < MAX_ID; ++i)
        visited[i] = 0;

    printf("Nhap 2 diem: "); scanf("%d %d", &s, &t);
    if (!jrb_find_int(G.vertices, s) || !jrb_find_int(G.vertices, t))
    {
        printf("Khong co duong di\n");
        return;
    }
    backtrack(G, s, t, &n);
    printf("Paths: %d\n", n);
}

int main()
{
    // Menu
    Graph G = createGraph();
    char file_name[50];
    int select;
    do
    {
        puts("");
        puts("MENU: ");
        printf(">>> "); scanf("%d", &select);
        switch (select)
        {
        case 1:
            printf("Nhap ten file chua ma tran vuong: "); fflush(stdin); scanf("%s", file_name);
            if(!read_file(G, file_name))
            {
                dropGraph(G);
                return 0;
            }
            break;
        case 2:
            func2(G);
            break;
        case 3:
            func3(G);
            break;
        case 4:
            func4(G);
            break;
        case 5:
            func5(G);
            break;
        case 6:
            func6(G);
            break;
        case 7:
            func7(G);
            break;
        default:
            break;
        }
    } while (select >= 1 && select <= 7);

    dropGraph(G);
    return 0;
}