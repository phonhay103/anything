#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "graph.h"

// Tao mot cay JRB de luu giu ID - Ten San Pham (Vi qua dai va khong can thiet cho vo graph :\)
JRB input_SP(char* file_name, int* m) // m la so luong san pham
{
    JRB tree = make_jrb();
    FILE* f = fopen(file_name, "r");
    char name[20];
    int id;

    fscanf(f, "%d\n", m);
    for (int i = 0; i < *m; ++i)
    {
        fscanf(f, "%s %d\n", name, &id);
        jrb_insert_int(tree, id, new_jval_s(strdup(name)));
    }

    fclose(f);
    return tree;
}

// Tao graph luu giu: ID-Ten kho hang | Lien ket kho hang (ID - ID) | ID_kho_hang - (ID_san_pham - so luong)
Graph intput_KH(char* file_name, int m)
{
    Graph G = createGraph();
    FILE* f = fopen(file_name, "r");
    int n;
    char name[30];
    int id1, id2, amout;
    double distance;

    // Nhập kho hàng và sản phẩm (n kho hang)
    fscanf(f, "%d\n", &n);
    for (int i = 0; i < n; ++i)
    {
        // Nhập ID và tên các kho hàng
        fscanf(f, "%s %d\n", name, &id1);
        addVertex(G, id1, name);

        // m hang tiep theo la so luong cua tung loai san pham co trong kho hang
        JRB tree = make_jrb();
        jrb_insert_int(G.SP, id1, new_jval_v(tree));
        for (int i = 0; i < m; ++i)
        {
            fscanf(f, "%d %d\n", &id1, &amout);
            jrb_insert_int(tree, id1, new_jval_i(amout));
        }
    }

    // Nhập liên kết giữa các kho hàng (n dong cuoi la n lien ket cua do thi vo huong)
    fscanf(f, "%d\n", &n);
    for (int i = 0; i < n; ++i)
    {
        fscanf(f, "%d %d %lf\n", &id1, &id2, &distance);
        addEdge(G, id1, id2, distance);
        addEdge(G, id2, id1, distance);
    }

    fclose(f);
    return G;
}

// Lấy số lượng của 1 sản phẩm trong 1 kho hàng (G.SP)
int getSL(Graph G, int id_kh, int id_sp)
{
    JRB tree = (JRB) jval_v(jrb_find_int(G.SP, id_kh)->val);
    JRB node = jrb_find_int(tree, id_sp);
    return jval_i(node->val);
}

// Kiểm tra tồn tại sản phẩm (tree)
int isProductExist(JRB tree, int id_sp)
{
    if (!jrb_find_int(tree, id_sp))
        return 0;
    return 1;
}

// Kiểm tra tồn tại kho hàng (G.vertices)
int isWarehouseExist(Graph G, int id_kh)
{
    if (!jrb_find_int(G.vertices, id_kh))
        return 0;
    return 1;
}

void argv_t()
{
    printf("C-Advanced, HK20182\n");
}

void argv_s(char* argv[])
{
    int m;
    JRB SP = input_SP(argv[2], &m);
    JRB iter;
    jrb_traverse(iter, SP)
        printf("%s %d\n", jval_s(iter->val), jval_i(iter->key));
    jrb_free_tree(SP);
}

void argv_w(char* argv[])
{
    int m;
    JRB SP = input_SP(argv[3], &m);
    Graph KH = intput_KH(argv[2], m);
    int id_kh1 = atoi(argv[4]);
    int id_kh2 = atoi(argv[5]);

    if (isWarehouseExist(KH, id_kh1) && isWarehouseExist(KH, id_kh1))
    {
        double distance = getEdgeValue(KH, id_kh1, id_kh2);
        if (distance == INFINITIVE_VALUE)
            printf("-1\n");
        else
            printf("%.0lfkm\n", distance);
    }
    else
        printf("-1\n");

    jrb_free_tree(SP);
    dropGraph(KH);
}

void argv_a(char* argv[])
{
    int m;
    JRB SP = input_SP(argv[3], &m);
    Graph KH = intput_KH(argv[2], m);
    JRB iter1, iter2, tree, node;
    jrb_traverse(iter1, KH.SP)
    {
        printf("%s %d\n", getVertex(KH, jval_i(iter1->key)), jval_i(iter1->key));
        tree = (JRB) jval_v(iter1->val);
        jrb_traverse(iter2, tree)
        {
            node = jrb_find_int(SP, jval_i(iter2->key));
            printf("%s %d\n", jval_s(node->val), jval_i(iter2->val));
        } 
        if (jrb_next(iter1) != jrb_nil(KH.SP))
            printf("-----\n");
    }
    jrb_free_tree(SP);
    dropGraph(KH);
}

void argv_h(char* argv[])
{
    int m;
    JRB SP = input_SP(argv[3], &m);
    int id_sp = atoi(argv[4]);
    if (!isProductExist(SP, id_sp))
    {
        printf("San pham ID-%d khong ton tai\n", id_sp);
        return;
    }

    Graph KH = intput_KH(argv[2], m);
    int id_kh = atoi(argv[5]);
    if (!isWarehouseExist(KH, id_kh))
    {
        printf("Kho hang ID-%d khong ton tai\n", id_kh);
        return;
    }

    char* ten_sp = jval_s(jrb_find_int(SP, id_sp)->val);

    JRB node, tree;
    printf("%s\n", getVertex(KH, id_kh));
    tree = (JRB) jval_v(jrb_find_int(KH.SP, id_kh)->val); // Cay JRB chua danh sach san pham va so luong cua chung trong kho hang
    node = jrb_find_int(tree, id_sp);
    int so_luong = jval_i(node->val);
    printf("%s %d\n", ten_sp, so_luong);

    int n, output[100];
    n = outdegree(KH, id_kh, output);
    if (n > 0)
    {
        printf("---- Cac kho ke la: \n");
        for (int i = 0; i < n; ++i)
        {
            printf("%s\n", getVertex(KH, output[i]));
            tree = (JRB) jval_v(jrb_find_int(KH.SP, output[i])->val);
            node = jrb_find_int(tree, id_sp);
            so_luong = jval_i(node->val);
            printf("%s %d\n", ten_sp, so_luong);
        }
    }

    jrb_free_tree(SP);
    dropGraph(KH);
}

void argv_g(char* argv[])
{
    int m;
    JRB SP = input_SP(argv[3], &m);
    int id_sp = atoi(argv[4]);
    int amount = atoi(argv[5]);
    if (!isProductExist(SP, id_sp))
    {
        printf("San pham ID-%d khong ton tai\n", id_sp);
        return;
    }

    Graph KH = intput_KH(argv[2], m);
    int id_kh1 = atoi(argv[6]);
    if (!isWarehouseExist(KH, id_kh1))
    {
        printf("Kho hang ID-%d khong ton tai\n", id_kh1);
        return;
    }
    int id_kh2 = atoi(argv[7]);
    if (!isWarehouseExist(KH, id_kh2))
    {
        printf("Kho hang ID-%d khong ton tai\n", id_kh2);
        return;
    }

    if (getSL(KH, id_kh1, id_sp) >= amount)
        printf("Dat hang thanh cong. Thoi gian giao hang la 30 phut\n");
    else if (getSL(KH, id_kh1, id_sp) + getSL(KH, id_kh2, id_sp) < amount)
        printf("Dat hang khong thanh cong\n");
    else
    {
        int path[MAX_ID], lenght;
        double distance = shortestPath(KH, id_kh1, id_kh2, path, &lenght);
        double time = 0.5 + distance/30;
        printf("Dat hang thanh cong. Thoi gian giao hang la %d gio %.0lf phut\n", (int)time, (time-(int)time)*60);
    }
    
    jrb_free_tree(SP);
    dropGraph(KH);
}

int main(int argc, char* argv[])
{
    if (argc == 1)
        return 0;
    if (strcmp(argv[1], "-t") == 0)
        argv_t();
    else if (strcmp(argv[1], "-s") == 0)
        argv_s(argv);
    else if (strcmp(argv[1], "-w") == 0)
        argv_w(argv);
    else if (strcmp(argv[1], "-a") == 0)
        argv_a(argv);
    else if (strcmp(argv[1], "-h") == 0)
        argv_h(argv);
    else if (strcmp(argv[1], "-g") == 0)
        argv_g(argv);
    return 0;
}