#include <stdio.h>
#include "graph.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void read_file(Graph G)
{
    FILE* f = fopen("products.txt", "r");
    int id;
    char name[1000];
    fscanf(f, "%d %s\n", &id, name);
    addVertex(G, id, name);
    while (fscanf(f, "%d %s\n", &id, name) != -1)
        addVertex(G, id, name);
    fclose(f);

    char str[1000], *tmp;
    int n;
    int arr_id[1000];
    f = fopen("orderhistory.txt", "r");
    while (fgets(str, 1000, f))
    {
        n = 0;
        arr_id[n++] = atoi(strtok(str, " "));
        while (1)
        {
            tmp = strtok(NULL, " ");
            if (tmp == NULL)
                break;
            arr_id[n++] = atoi(tmp);
        }
        for (int i = 0; i < n-1; ++i)
            for (int j = i+1; j < n; ++j)
            {
                addEdge(G, arr_id[i], arr_id[j], 1); // Da sua lai ham nay (graph.c)
                addEdge(G, arr_id[j], arr_id[i], 1); // Da sua lai ham nay (graph.c)
            }
    }
    fclose(f);

    // JRB iter, tree, node;
    // jrb_traverse(iter, G.edges)
    // {
    //     printf("ID-%d: ", jval_i(iter->key));
    //     tree = (JRB) jval_v(iter->val);
    //     jrb_traverse(node, tree)
    //     {
    //         printf("%d_%.0lf\t", jval_i(node->key), jval_d(node->val));
    //     }
    // }
}

void func1(Graph G)
{
    JRB iter;
    jrb_traverse(iter, G.vertices)
    {
        printf("Ma san pham: %d\n", jval_i(iter->key));
        printf("Ten san pham: %s\n", jval_s(iter->val));
        puts("");
    }
}

void func2(Graph G)
{
    char str[1000], *tmp;
    FILE* f = fopen("orderhistory.txt", "r");
    while (fgets(str, 1000, f))
    {
        printf("%s ", getVertex(G, atoi(strtok(str, " "))));
        while (1)
        {
            tmp = strtok(NULL, " ");
            if (tmp == NULL)
                break;
            printf("%s ", getVertex(G, atoi(tmp)));
        }
        puts("");
    }
    fclose(f);
}

void func3(Graph G)
{
    int id1, id2;
    printf("Nhap id 2 san pham: "); scanf("%d %d", &id1, &id2);
    double corr = getEdgeValue(G, id1, id2);
    if (corr == INFINITIVE_VALUE)
       corr = -1;
    printf("Do lien quan giua 2 san pham: %.0lf\n", corr);
}

void func4(Graph G)
{
    int n, output[MAX_ID];
    int id;
    int tmp;

    printf("Nhap ma san pham: "); scanf("%d", &id);
    n = outdegree(G, id, output);
    for (int i = 0; i < n-1; ++i)
        for (int j = i+1; j < n; ++j)
            if (output[i] > output[j])
            {
                tmp = output[i];
                output[i] = output[j];
                output[j] = tmp;
            }
    printf("Cac san pham lien quan: ");
    for (int i = 0; i < n; ++i)
        printf("%s ", getVertex(G, output[i]));
}

void func5(Graph G)
{
    int id1, id2;
    int length, path[MAX_ID];

    printf("Nhap ID 2 san pham: "); scanf("%d %d", &id1, &id2);
    if (!jrb_find_int(G.vertices, id1) || !jrb_find_int(G.vertices, id2))
        return;

    double corr = shortestPath(G, id1, id2, path, &length);
    if (corr == INFINITIVE_VALUE)
        printf("Hai san pham nay khong co lien he voi nhau\n");
    else
    {
        for (int i = 0; i < length-1; ++i)
            printf("%s - ", getVertex(G, path[i]));
        printf("%s\n", getVertex(G, path[length-1]));
    }
    
}

int main()
{
    // Menu
    Graph G = createGraph();
    read_file(G);
    int select;
    do
    {
        puts("");
        puts("MENU: ");
        // puts("1. Doc file");
        // puts("2. PageRank 1 lan");
        // puts("3. PageRank m lan");
        // puts("4. ?");
        // puts("5. Khoang cach nho nhat");
        // puts("6. Thoat");
        printf(">>> "); scanf("%d", &select);
        switch (select)
        {
        case 1:
            func1(G);
            break;
        case 2:
            func2(G);
            break;
        case 3:
            func3(G);
            break;
        case 4:
            func4(G);
            break;
        case 5:
            func5(G);
            break;
        default:
            break;
        }
    } while (select >= 1 && select <= 6);

    dropGraph(G);
    return 0;
}