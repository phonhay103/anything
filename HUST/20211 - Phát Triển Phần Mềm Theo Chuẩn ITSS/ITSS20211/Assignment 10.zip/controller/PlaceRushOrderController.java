package controller;

import java.sql.Date;

public class PlaceRushOrderController {
	public boolean validateTime(Date receiveTime) {
//		check the receive date after order date 
		Date currentDate = new Date(System.currentTimeMillis());
		if (receiveTime.compareTo(currentDate) == 0 || receiveTime.before(currentDate) == true) {
			return false;
		}
		
		return true;
	}
	
	public boolean validateInstruction(String instruction) {
//		check the instruction is not null
		if (instruction.isEmpty() == true) {
			return false;
		}
		
		return true;
	}
}
